import java.io.IOException;
import java.util.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class 10050Mapper extends Mapper <LongWritable, Text, Text, Text> 
{
  static int start100;
  static int start50;

  public void setup(Context context) throws IOException, InterruptedException
  {
    Configuration conf = context.getConfiguration();
    start100 = Integer.valueOf(conf.get("start100"));
    start50 = Integer.valueOf(conf.get("start50"));
  }

  public void map(LongWritable key, Text value,Context context) throws IOException, InterruptedException
  {
    try
    {
      String fields[] = value.toString().split(",");
      String name = fields[0];
      String match_100 = fields[10];
      String match_50 = fields[11];
    
      if (start100 <= match_100 && start50 <= match_50)   //15 < 20 && 40 < 45
      {
        context.write(new Text(name),new Text(new IntWritable(match_100).toString()+","+new IntWritable(match_50).toString()));
      }
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }
}

