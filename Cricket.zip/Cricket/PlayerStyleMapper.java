import org.apache.hadoop.conf.Configuration;
import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class PlayerStyleMapper extends Mapper <LongWritable, Text, Text, Text >
{
	static String batting;
	static String bowling;

	public void setup(Context context) throws IOException, InterruptedException
	{
	    Configuration conf = context.getConfiguration();
	    batting = conf.get("battingStyle");
	    bowling = conf.get("bowlingStyle");
	}

	public void map (LongWritable key, Text value, Context context ) throws IOException, InterruptedException
	{
		try 
		{
			String fields[] = value.toString().split(",");
			String name = fields[0];
			String battingStyle = fields[7];
			String bowlingStyle = fields[8];

			if (battingStyle.contains(batting) && bowlingStyle.contains(bowling))
			{
				context.write(new Text(name), new Text(new Text(battingStyle)+" , "+new Text(bowlingStyle)));
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}


