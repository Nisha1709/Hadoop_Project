import java.io.IOException;
import java.util.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public  class SpanYearMapper extends Mapper<LongWritable, Text, Text, Text> //Inputkey, Input value, Output key, Output value
{
  static int startYear;
  static int endYear;

  public void setup(Context context) throws IOException, InterruptedException
  {
    Configuration conf = context.getConfiguration();
    startYear = Integer.valueOf(conf.get("startYear"));
    endYear = Integer.valueOf(conf.get("endYear"));
  }

  public void map(LongWritable key, Text value,Context context) throws IOException, InterruptedException
  {
    try
    {
      int start_year;
      int end_year;
      String fields[] = value.toString().split(",");
      String name = fields[0];
      String year = fields[1];
      start_year = Integer.valueOf(year.substring(0,4));
      end_year = Integer.valueOf(year.substring(5,9));
      if (startYear <= start_year && endYear >= end_year)   //1995 < 1996 && 2015 > 2011
      {
        context.write(new Text(name),new Text(new IntWritable(start_year).toString()+"-"+new IntWritable(end_year).toString()));
      }
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }
}

