import java.io.IOException;
import java.util.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public  class PlayerCityMapper extends Mapper<LongWritable, Text, Text, Text> //Inputkey, Input value, Output key, Output value
{
  static String playerCity;

  public void setup(Context context) throws IOException, InterruptedException
  {
    Configuration conf = context.getConfiguration();
    playerCity = conf.get("playerCity");
  }

  public void map(LongWritable key, Text value,Context context) throws IOException, InterruptedException
  {
    try
    {
      String player_city;
      String fields[] = value.toString().split(",");
      String name = fields[0];
      String city = fields[4];
      if (city.contains(playerCity))
      {
        context.write(new Text(name),new Text(city));
      }
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }
}

