import java.io.IOException;
import java.util.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public  class MaxScoreNOMapper extends Mapper<LongWritable, Text, Text, IntWritable> //Inputkey, Input value, Output key, Output value
{
   
  public void map(LongWritable key, Text value,Context context) throws IOException, InterruptedException
  {
    try
    {
      String fields[] = value.toString().split(",");
      String name = fields[0];
      String high_score = fields[6];
     // String span = fields[1];
      int score;

      if (high_score.contains("*"))
      {
        score = Integer.valueOf(high_score.substring(0,3));
        context.write(new Text(name),new IntWritable(score));
      }
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }
}

