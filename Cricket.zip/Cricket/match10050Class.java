//List out players and their number of matches played were they have scored 100 and 50 and the minn number of matches is mentioned by the user. 

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.conf.Configuration;

public class match10050Class
{
	public static void main (String args[]) throws Exception
	{
		
		Configuration conf = new Configuration ();
		Job job = new Job(conf,"match10050Class");
		job.setJarByClass(match10050Class.class);
		job.setJar("match10050Class.jar");
		job.setJobName("match10050Class");
		
		FileInputFormat.addInputPath(job, new Path (args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
	
		job.setMapperClass(match10050Mapper.class);
		job.setReducerClass(match10050Reducer.class);


		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);

		job.getConfiguration().set("start100",args[2]);
		job.getConfiguration().set("start50",args[3]);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}

/*
*****Steps*****

javac -classpath /I:/hadoop-3.0.0/share/hadoop/common/hadoop-common-3.0.0.jar;/I:/hadoop-3.0.0/share/hadoop/mapreduce/hadoop-mapreduce-client-core-3.0.0.jar;/I:/Practice_Hadoop/Cricket/ match10050Mapper.java

javac -classpath /I:/hadoop-3.0.0/share/hadoop/common/hadoop-common-3.0.0.jar;/I:/hadoop-3.0.0/share/hadoop/mapreduce/hadoop-mapreduce-client-core-3.0.0.jar;/I:/Practice_Hadoop/Cricket/ match10050Reducer.java

javac -classpath /I:/hadoop-3.0.0/share/hadoop/common/hadoop-common-3.0.0.jar;/I:/hadoop-3.0.0/share/hadoop/mapreduce/hadoop-mapreduce-client-core-3.0.0.jar;/I:/Practice_Hadoop/Cricket/ match10050Class.java

jar cvf match10050Class.jar match10050Mapper.class match10050Reducer.class match10050Class.class

jar tvf match10050Class.jar  

hadoop jar match10050Class.jar match10050Class /data/Cricket.csv /data/Cricket/match10050_Output 15 40

hadoop fs -cat /data/Cricket/match10050_Output/*

*/