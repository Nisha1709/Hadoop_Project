import java.io.IOException;
import java.util.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class match10050Mapper extends Mapper <LongWritable, Text, Text, Text> 
{
  static int start100;
  static int start50;

  public void setup(Context context) throws IOException, InterruptedException
  {
    Configuration conf = context.getConfiguration();
    start100 = Integer.valueOf(conf.get("start100"));
    start50 = Integer.valueOf(conf.get("start50"));
  }

  public void map(LongWritable key, Text value,Context context) throws IOException, InterruptedException
  {
    try
    {
      int start_100;
      int start_50;
      String fields[] = value.toString().split(",");
      String name = fields[0];
      String match_100 = fields[10];
      String match_50 = fields[11];
      start_100 = Integer.valueOf(match_100);
      start_50 = Integer.valueOf(match_50);

      if (start100 <= start_100 && start50 <= start_50)   //15 < 20 && 40 < 45
      {
        context.write(new Text(name),new Text(new IntWritable(start_100).toString()+","+new IntWritable(start_50).toString()));
      }
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }
}

