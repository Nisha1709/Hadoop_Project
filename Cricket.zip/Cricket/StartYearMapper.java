import java.io.IOException;
import java.util.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public  class StartYearMapper extends Mapper<LongWritable, Text, Text, IntWritable> //Inputkey, Input value, Output key, Output value
{
  static int startYear;

  public void setup(Context context) throws IOException, InterruptedException
  {
    Configuration conf = context.getConfiguration();
    startYear = Integer.valueOf(conf.get("startYear"));
  }

  public void map(LongWritable key, Text value,Context context) throws IOException, InterruptedException
  {
    try
    {
      int start_year;
      String fields[] = value.toString().split(",");
      String name = fields[0];
      String year = fields[1];
      start_year = Integer.valueOf(year.substring(0,4));
      if (start_year > startYear)
      {
        context.write(new Text(name),new IntWritable(start_year));
      }
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }
}

