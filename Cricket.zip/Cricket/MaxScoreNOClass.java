//Who is the highest run scorer in the list without getting NOT OUT in the match.

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.conf.Configuration;

public class MaxScoreNOClass
{
	public static void main (String args[]) throws Exception
	{
		
		Configuration conf = new Configuration ();
		Job job = new Job(conf,"MaxScoreNOClass");
		job.setJarByClass(MaxScoreNOClass.class);
		job.setJar("MaxScoreNOClass.jar");
		job.setJobName("MaxScoreNOClass");
		
		FileInputFormat.addInputPath(job, new Path (args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
	
		job.setMapperClass(MaxScoreNOMapper.class);
		job.setReducerClass(MaxScoreNOReducer.class);


		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}

/*
*****Steps*****

javac -classpath /I:/hadoop-3.0.0/share/hadoop/common/hadoop-common-3.0.0.jar;/I:/hadoop-3.0.0/share/hadoop/mapreduce/hadoop-mapreduce-client-core-3.0.0.jar;/I:/Practice_Hadoop/Cricket/ SR100Mapper.java

javac -classpath /I:/hadoop-3.0.0/share/hadoop/common/hadoop-common-3.0.0.jar;/I:/hadoop-3.0.0/share/hadoop/mapreduce/hadoop-mapreduce-client-core-3.0.0.jar;/I:/Practice_Hadoop/Cricket/ SR100Reducer.java

javac -classpath /I:/hadoop-3.0.0/share/hadoop/common/hadoop-common-3.0.0.jar;/I:/hadoop-3.0.0/share/hadoop/mapreduce/hadoop-mapreduce-client-core-3.0.0.jar;/I:/Practice_Hadoop/Cricket/ SR100Class.java

jar cvf SR100Class.jar SR100Mapper.class SR100Reducer.class SR100Class.class  

jar tvf SR100Class.jar  

hadoop jar SR100Class.jar SR100Class /data/Cricket.csv /data/Cricket/SR100_Output 

hadoop fs -cat /data/Cricket/SR100_Output/* 

*/