
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class SR100Reducer extends Reducer <Text , LongWritable, Text , DoubleWritable>
{
	public void reduce(Text key, DoubleWritable value, Context context) throws IOException, InterruptedException
     {
     	context.write(key, value);	
     }
}
