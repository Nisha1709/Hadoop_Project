
import java.io.IOException;
import java.lang.*;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SR100Mapper extends Mapper <LongWritable, Text, Text, DoubleWritable >
{

	public void map (LongWritable key, Text value, Context context ) throws IOException, InterruptedException
	{
		try
		{
			String fields[] = value.toString().split(",");
			String name = fields[0];
			double strike_rate = Double.valueOf(fields[9]);
			if (strike_rate > 100.00)
			{
			context.write(new Text(name), new DoubleWritable(strike_rate));
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
}


